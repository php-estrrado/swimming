<?php
Route::group(['prefix' => 'coach'], function() {
    Route::get('/students', 'Coach\StudentController@students');
    Route::get('student/{id}', ['uses' => 'Coach\StudentController@student'], function($id) { })->where('id', '[0-9/]+');
    
    Route::post('/update/course/percent', 'Coach\StudentController@updatePercent');
});