<?php

namespace App\Models\Admin;

use DB;

class Page extends User {
    
}
