<?php

namespace App\Models\Admin;

use DB;

class Widget extends User {
    
}
