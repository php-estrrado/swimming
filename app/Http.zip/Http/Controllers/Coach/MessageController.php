<?php

namespace App\Http\Controllers\Coach;


use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;

use App\Models\Coach\Message;
use App\Models\Functions;
use Validator;
use Session;

class MessageController extends Controller{
    public function __construct(){ $this->middleware('auth'); }
  
    public function index(Request $request){
        $post                       =   $request->post();
        $data['userData']           =   Session::get('userData');
        $data['chatList']           =   Message::chatList(auth()->user()->id,'','','data');
        $data['chatHistory']        =   Message::getChatHistory(auth()->user()->id,0,'data');
        $data['title']              =   'Messages';
        return view('coach.pages.messages.message', $data);
    }
    
    function message($id){
        $data['chatHistory']        =   Message::getChatHistory(auth()->user()->id,$id,'data');
        return view('coach.pages.messages.content', $data);
    }
    
    function getMessage(Request $request){
        $post                       =   (object)$request->post();
        $messages                   =   Message::getChatMessages($post->chat_id,auth()->user()->id,'data',$post->last_id);
        $data['msgs']               =   $messages;
        if(count($messages)         >   0){ $lastId =  $messages['last_id']; }else{  $lastId = $post->last_id; }
        $data['last_id']            =   $lastId;
        return $data;
      //  return view('coach.pages.messages.new_messages', $data);
    }
    
    function save(Request $request){ 
        $post                       =   (object)$request->post(); 
        $result                     =   Message::sendChatMessage(auth()->user()->id,$post);
        return 'success';
    }

    public function fnf() {
        return Redirect::to('coach');
    }

}

