<?php

namespace App\Http\Controllers\Coach;


use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;


use App\Models\Coach\Student;
use Validator;

class StudentController extends Controller
{
    public function __construct(){
        $this->middleware('auth');
    }
  
    public function students(Request $request){
        $data['studentGroup']       =   'is-expanded active';
        $data['studentMenu']        =   'active';
        $data['title']              =   'Students';
        $data['students']           =   Student::students(auth()->user()->id);
        return view('coach.pages.students.list', $data);
    }
    
    public function student($id){
        $data['studentGroup']       =   'is-expanded active';
        $data['studentMenu']        =   'active';
        $student                    =   Student::student(auth()->user()->id,$id);
        $data['title']              =   $student->name;
        $data['student']            =   $student;
        $data['parentName']         =   Student::getParentName($student->parent);
        $data['regCourses']         =   Student::getRegCoursesByStudentId(auth()->user()->id,$student->user_id);
        return view('coach.pages.students.details', $data);
    }
    
    function updatePercent(Request $request){
        return Student::updateCoursePercent((object)$request->post());
    }
}
