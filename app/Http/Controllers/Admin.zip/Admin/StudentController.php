<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;


use App\Rules\Name;
use App\Models\Admin\Student;
use Validator;

class StudentController extends Controller
{
    public function __construct() {
        $this->middleware('authadmin:admin');
    }
    public function students()
    {
        $data['title']          =   'Students';
        $data['userGroup']      =   'is-expanded active';
        $data['studentMenu']    =   'active';
        $data['students']       =   Student::getStudents();
        return view('admin.pages.students.list', $data);
    }

    public function student($id=0)
    { 
        $data['title']          =   'New Student';
        $data['id']             =   $id;
        $data['userGroup']      =   'is-expanded active';
        $data['studentMenu']    =   'active';
        $data['student']        =   Student::getStudent($id);
        if($data['student']){       $data['title'] = $data['student']->name; }
        return view('admin.pages.students.details', $data);
    }

    public function updateStatus(Request $request)
    {
        $result                 =   Student::updateStatus((object)$request->post()); 
        if($request->post('active') == 1){ $msg = 'Activated successfully!'; }else{ $msg = 'Deactivated sucessfully!'; }
        if($result){ return array('type'=>'success','msg'=>$msg); }else{  return array('type'=>'warning','msg'=>'Status update failed.'); }
    }

   function disable(Request $request){
        $post                   =   (object)$request->post();
        $result                 =   Student::deleteStudent($post);
        if($result){ 
            $data['students']   =   Student::getStudents(); 
            return view('admin.pages.students.list.content', $data);
        }else{  return array('type'=>'warning','msg'=>'Failed to delete.'); }
    }
    
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function save(Request $request)
    {
        $post               =   (object)$request->post();
        $rules              =   [
                                    'name'          =>  ['required', 'string', new Name],
                                    'phone'         =>  'required|numeric|digits_between:7,13|unique:users,phone,'.$post->cId.',id',
                                    'email'         =>  'string|email|max:255|unique:users,email,'.$post->cId.',id',
                                    'address1'      =>  'required|string|max:255'
                                ];
        if($post->cId       ==  0){ $rules['password']  =   'required|string|min:6|max:55'; }
        else if($post->password != ''){ $rules['password']  =   'required|string|min:6|max:55'; }
        $validator                      =   Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return redirect('/admin/user/student/'.$post->cId)->withErrors($validator)->withInput();
        }else{
            $result         =   Student::saveStudent($post,$post->cId);
            if($result){
                if($post->cId > 0){ $mag = 'Student Updated Successfully!'; }else{ $mag = 'Student Added Successfully!'; }
                return redirect('/admin/user/students')->with('success', $mag);
            }else{ return redirect('/admin/user/student/'.$post->cId)->with('success', 'Failed. Some error occured'); }
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
